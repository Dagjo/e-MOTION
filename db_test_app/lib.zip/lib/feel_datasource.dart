import 'dart:async';
import 'dart:io';
import 'package:path_provider/path_provider.dart';
import 'package:path/path.dart';
import 'package:db_test_app/feel_database.dart';
import 'package:db_test_app/journal_entry.dart';

class FeelDataSource {

  String _databasePath;

  FeelDataSource();

  Future<FeelDatabase> get _database async {
    if (_databasePath == null) {
      Directory documentsDirectory = await getApplicationDocumentsDirectory();
      _databasePath = join(documentsDirectory.path, "feel.db");
    }

    return FeelDatabase(_databasePath);
  }

  Future<List<JournalEntry>> getJournalEntries() async {
    FeelDatabase db;
    try {
      db = await _database;
      await db.open();
      List<Map> entries = await db.readJournalEntries();
      db.close();

      if (entries == null)
        return new List<JournalEntry>();

      List<JournalEntry> list = new List<JournalEntry>();
      for(Map entry in entries)
        list.add(JournalEntry.fromMap(entry));
      return list;
    }
    catch (e) {
      db?.close();
      var x = e;
    }
    return null;
  }

  deleteJournalEntry(JournalEntry journalEntry) async {
    FeelDatabase db;
    try {
      db = await _database;
      await db.open();
      await db.deleteJournalEntry(journalEntry.created.millisecondsSinceEpoch);
      db.close();
    }
    catch (e) {
      db?.close();
      var x = e;
    }
  }

  saveJournalEntry(JournalEntry journalEntry) async {
    FeelDatabase db;
    try {
      db = await _database;
      await db.open();
      await db.insertJournalEntry(journalEntry.created.millisecondsSinceEpoch, journalEntry.body);
      db.close();
    }
    catch (e) {
      db?.close();
      var x = e;
    }
  }
}