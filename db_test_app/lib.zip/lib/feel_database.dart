import 'dart:async';
import 'dart:io';
import 'package:path/path.dart';
import 'package:path_provider/path_provider.dart';
import 'package:sqflite/sqflite.dart';

Future<String> getDefaultFeelDatabasePath() async {
  Directory documentsDirectory = await getApplicationDocumentsDirectory();
  return join(documentsDirectory.path, 'feel.db');
}

class FeelDatabase {

  String _databasePath;
  Database _database;

  final int _version = 1;

  static const String _journalEntryTableCreationSql =
      'CREATE TABLE JournalEntry (Created INTEGER PRIMARY KEY, Body TEXT)';

  static const String _journalEntrySelectAllSql =
      'SELECT Created, Body FROM JournalEntry';

  static const String _journalEntryInsertSql =
      'INSERT INTO JournalEntry (Created, Body) VALUES (?, ?)';

  static const String _journalEntryDeleteSql =
      'DELETE FROM JournalEntry WHERE Created = ?';

  FeelDatabase(this._databasePath);

  open() async {
    if (_database != null)
      throw new Exception('Database is already open');

    _database = await openDatabase(_databasePath,
        version: _version,
        onCreate: await _initializeDatabase);
  }

  close() async {
    if (_database != null)
      return await _database.close();
  }

  _initializeDatabase(Database db, int version) async {
    // When creating the db, create the table
    return await db.execute(_journalEntryTableCreationSql);
  }

  Future<List<Map>> readJournalEntries() async {
    return await _database.rawQuery(_journalEntrySelectAllSql);
  }

  insertJournalEntry(int created, String body) async {
    return await _database.rawInsert(_journalEntryInsertSql, [created, body]);
  }

  deleteJournalEntry(int created) async {
    return await _database.rawInsert(_journalEntryDeleteSql, [created]);
  }
}